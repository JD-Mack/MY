#8. A python program to copy an image file into another file.
f=open("/Users/exam/Desktop/A53/File/download.jpeg","rb")
a=f.read()
f.close()
f=open("/Users/exam/Desktop/A53/File/cat.jpeg","wb")
f.write(a)
f.close()