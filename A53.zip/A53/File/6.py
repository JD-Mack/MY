#6. A python program to know wheather the file exists or not.
import os
booll=os.path.isfile("/Users/exam/Desktop/A53/File/Text.txt")
if booll:
	print("File Exist")
else:
	print("File does not Exist")