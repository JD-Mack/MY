#1. write a python program to create a text file to store individual characters.
f=open("/Users/exam/Desktop/A53/File/Text.txt","w")
f.write("Hello Jaydeep!!!!")