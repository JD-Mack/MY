#4. A python program to read all the strings from text file and display them.
f=open("/Users/exam/Desktop/A53/File/Text.txt","r")
print(f.read())