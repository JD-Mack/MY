#5. A python program to append data to an existing file and then display the entire file data.
f=open("/Users/exam/Desktop/A53/File/Text.txt","a+")
f.write("ABCDEF")
print(f.tell())
f.seek(0,0)
a=f.read()
print(a)
f.close()