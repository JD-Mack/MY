#2. write a python program to read first 5 bytes from a text file.
f=open("/Users/exam/Desktop/A53/File/Text.txt","r")
print(f.read(5))