#3. Write a python program to store a group of strings into a text file.
f=open("/Users/exam/Desktop/A53/File/Text.txt","a")
f.write("NIDHI!!!! ANIS!!!! JAY!!!! PRITESH!!!!")