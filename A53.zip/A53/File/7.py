#7. A python program to count number of lines, words and characters in a text file.
f=open("/Users/exam/Desktop/A53/File/Text.txt","r")
a=f.read()
line=0
words=0
char=0
for i in a:
	if i==' ':
		words+=1
	elif i=='\n':
		line+=1
	char+=1
print("No.of Lines:",line)
print("No.of Words:",words)
print("No.of Character:",char)