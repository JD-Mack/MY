#9. A python program to use with to open a file and write some string into file.
with open("/Users/exam/Desktop/A53/File/Text.txt","w") as File:
	File.write("ABCDEF")