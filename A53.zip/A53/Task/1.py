#1.write a program to create lambda function that returns a square value of a given number.
def my():
	return lambda a:a*a
n=int(input("Enter a number to return its square:"))
mylambda=my()
print("Square is:",mylambda(n))