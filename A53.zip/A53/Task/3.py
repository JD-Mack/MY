#3. A lambda funtion to find the bigger number in to two given numbers.
n=int(input("Enter First Number:"))
n1=int(input("Enter Second Number:"))
mylambda=lambda a,b:a if a>b else b
print("Bigger Number is:",mylambda(n,n1))