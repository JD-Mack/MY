#4. Write a python program using filter() to filter out even numbers from list.
def is_even(x):
  if x%2==0:
    return True

  else:
    return False

lst=[1,2,3,4,5,6,7,8,9,10]

lst1=list(filter(is_even,lst)) 
print(lst1)