"""
8. write a program to find the products of elements of two different lists using
lambda function.
Lst1=1,2,3,4,5
lst2=10,20,30,40,50
OUTPUT: 10,40,90,160,250
"""
lst1=[1,2,3,4,5]
lst2=[10,20,30,40,50]
mylambda=lambda a,b:a*b
print("The products of elements of two different lists using lambda function:",map(mylambda,lst1,lst2))