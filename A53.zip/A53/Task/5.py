#5. A lambda that returns even numbers from a list.
lst=[1,2,3,4,5,6,7,8,9,10] 
my=lambda lst:True if lst%2==0 else False
print("Even Numbers From List Using Lambda:",filter(my,lst))