#7. Write a lambda function that returns a squares of elements in a list. (MAP(),lambda)
list=[1,2,3,4,5]
mylambda=lambda a:a*a
print("Square Number using lambdaFunction:",map(mylambda,list))