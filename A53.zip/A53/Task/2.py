#2. A lambda function to calculate the sum of two numbers.
n=int(input("Enter First Number:"))
n1=int(input("Enter Second Number:"))
myLambda=lambda a,b:a+b
print("Sum is:",myLambda(n,n1))