"""
9. To calculate the sum of numbers from 1 to 50, write reduce() function with a
lambda.
OUTPUT: 1275
"""
lst1=[]
for i in range(1,51):
	lst1.append(i)
mylambda=lambda a,b:a+b
print("The sum of numbers:",reduce(mylambda,lst1))