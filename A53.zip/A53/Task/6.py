#6. Write a python progran to find squares of elements in list. (MAP()FUNCTION)
def square(n):
	return n*n
lst=[1,2,3,4,5]
print("Square Number using MapFunction:",map(square,lst))